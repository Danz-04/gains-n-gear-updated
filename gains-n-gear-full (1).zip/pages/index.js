import Head from 'next/head'

export default function Home() {
  return (
    <div className="bg-black text-white min-h-screen p-6 space-y-16">
      <Head>
        <title>Gains & Gears</title>
      </Head>
      <section className="text-center space-y-4">
        <img
          src="/logo.png"
          alt="Gains & Gears Logo"
          className="mx-auto w-32 h-32"
        />
        <h1 className="text-4xl font-bold">Gains & Gears</h1>
        <p className="text-lg">The Ultimate Discord Hub for Building Wealth</p>
        <a href="https://whop.com/gains-gears/" target="_blank" rel="noreferrer">
          <button className="bg-yellow-500 text-black px-6 py-3 rounded-lg text-lg">
            🚀 Join the Community
          </button>
        </a>
      </section>
    </div>
  )
}